// Simpan data
const form = document.getElementById("cutiForm");
if (form) {
  form.addEventListener("submit", function(e) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    let cutiList = JSON.parse(localStorage.getItem("cutiList") || "[]");
    cutiList.push(data);
    localStorage.setItem("cutiList", JSON.stringify(cutiList));
    window.location.href = "index.html";
  });
}

// Tampilkan data
const table = document.getElementById("cutiTable");
if (table) {
  const tbody = table.querySelector("tbody");
  let cutiList = JSON.parse(localStorage.getItem("cutiList") || "[]");
  cutiList.forEach((cuti, i) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${i + 1}</td>
      <td>${cuti.nama}</td>
      <td>${cuti.jenis}</td>
      <td>${cuti.nosurat}</td>
      <td>${cuti.tglsurat}</td>
      <td>${cuti.dari}</td>
      <td>${cuti.sampai}</td>
      <td>${cuti.lama}</td>
      <td><button onclick="hapusData(${i})">🗑️</button></td>
    `;
    tbody.appendChild(row);
  });
}

// Hapus data
function hapusData(index) {
  if (confirm("Yakin ingin menghapus data ini?")) {
    let cutiList = JSON.parse(localStorage.getItem("cutiList") || "[]");
    cutiList.splice(index, 1);
    localStorage.setItem("cutiList", JSON.stringify(cutiList));
    location.reload();
  }
}

// Cetak PDF tabel dengan autoTable
function cetakPDF() {
  import('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js').then(jsPDFModule => {
    const { jsPDF } = jsPDFModule;
    import('https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js').then(() => {
      const doc = new jsPDF();
      const headers = [["No", "Nama", "Jenis Cuti", "No Surat", "Tgl Surat", "Dari", "Sampai", "Lama"]];
      let cutiList = JSON.parse(localStorage.getItem("cutiList") || "[]");
      const data = cutiList.map((c, i) => [
        i + 1, c.nama, c.jenis, c.nosurat, c.tglsurat, c.dari, c.sampai, c.lama
      ]);
      doc.text("Kartu Cuti Pegawai", 14, 10);
      doc.autoTable({
        startY: 20,
        head: headers,
        body: data
      });
      doc.save("kartu_cuti.pdf");
    });
  });
}
